<?php
include 'db.php';
include 'filter.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>.Eventease</title>

  <!-- CSS -->
  <link rel="stylesheet" href="css/events.css" />

  <!-- Bootstrap -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet" />

  <!-- Font -->
  <link
    href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&family=Abhaya+Libre:wght@400;500;600;700;800&family=Shrikhand&display=swap"
    rel="stylesheet" />

  <!-- Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" />

  <!-- Swiper CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
</head>

<body>
  <!-- Pre loader -->
  
  <?php include 'navbar.php'; ?>

  <div class="hero-gallery-container">
    <div class="hero-section">
      <div class="hero-content">
        <h1>.Eventease: Your Gateway to the Hottest Events in USU!</h1>
        <p>Find it, book it, live it. One click, all vibes.</p>
      </div>
    </div>
  </div>

  <section class="search">
    <div class="row justify-content-center">
      <div class="col-lg-8">
        <div class="search-container">
          <div class="search-bar">
            <form action="events.php" method="POST" enctype="multipart/form-data" class="search-form">
              <div class="search-group mb-3">
                <label for="eventSearch" class="search-label">Search Event</label>
                <input name="eventsearch" id="eventSearch" type="text" class="search-input" placeholder="Event Name"
                  value="<?= htmlspecialchars($_POST['eventsearch'] ?? '') ?>" />
              </div>
              <div class="search-group mb-3">
                <label for="placeInput" class="search-label">Place</label>
                <input id="placeInput" name="place_filter" type="text" class="search-input" placeholder="Enter location"
                  value="<?= htmlspecialchars($_POST['place_filter'] ?? '') ?>" />
              </div>
              <div class="search-group mb-3">
                <label for="timeSelect" class="search-label">Time</label>
                <select name="timesearch" id="timeSelect" class="search-select">
                  <option value="all" <?=($_POST['timesearch'] ?? 'all' )==='all' ? 'selected' : '' ?>>Any date</option>
                  <option value="today" <?=($_POST['timesearch'] ?? '' )==='today' ? 'selected' : '' ?>>Today</option>
                  <option value="tomorrow" <?=($_POST['timesearch'] ?? '' )==='tomorrow' ? 'selected' : '' ?>>Tomorrow
                  </option>
                  <option value="week" <?=($_POST['timesearch'] ?? '' )==='week' ? 'selected' : '' ?>>This week</option>
                  <option value="month" <?=($_POST['timesearch'] ?? '' )==='month' ? 'selected' : '' ?>>This month
                  </option>
                  <option value="offline" <?=($_POST['timesearch'] ?? '' )==='offline' ? 'selected' : '' ?>>Offline
                  </option>
                  <option value="free" <?=($_POST['timesearch'] ?? '' )==='free' ? 'selected' : '' ?>>Free</option>
                </select>
              </div>
              <div class="searchBtnContainer">
                <h3 type="submit" name="cari"><i class="fa-solid fa-magnifying-glass"></i></h3>
                <button type="submit" name="cari">FIND</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section> 

  <!-- Popular Events in USU -->
  <div class="popular-container">
    <section class="popular-events-section">
      <h2 class="section-title">Category Events in USU</h2>
      <form action="events.php" method="POST" enctype="multipart/form-data">
        <div class="filters">
          <button type="submit" name="category" value="all"
            class="filter-btn <?= (!isset($_POST['category']) || $_POST['category'] === 'all') ? 'active' : '' ?>">All</button>
          <button type="submit" name="category" value="music"
            class="filter-btn <?= ($_POST['category'] ?? '') === 'music' ? 'active' : '' ?>">Music</button>
          <button type="submit" name="category" value="art & culture"
            class="filter-btn <?= ($_POST['category'] ?? '') === 'art & culture' ? 'active' : '' ?>">Art &
            Culture</button>
          <button type="submit" name="category" value="food"
            class="filter-btn <?= ($_POST['category'] ?? '') === 'food' ? 'active' : '' ?>">Food & Beverage</button>
          <button type="submit" name="category" value="sports"
            class="filter-btn <?= ($_POST['category'] ?? '') === 'sports' ? 'active' : '' ?>">Sports</button>
          <button type="submit" name="category" value="entertainment"
            class="filter-btn <?= ($_POST['category'] ?? '') === 'entertainment' ? 'active' : '' ?>">Entertainment</button>
          <button type="submit" name="category" value="technology"
            class="filter-btn <?= ($_POST['category'] ?? '') === 'technology' ? 'active' : '' ?>">Techno</button>
          <button type="submit" name="category" value="learning & education"
            class="filter-btn <?= ($_POST['category'] ?? '') === 'learning & education' ? 'active' : '' ?>">Learning &
            Edu</button>
        </div>
      </form>
    </section>

    <div class="event-grid">
    <div class="swiper eventSwiper">
    <div class="swiper-wrapper">
        <?php
        // Contoh: Ambil semua event dari database
        $events = [];
        while ($event = pg_fetch_assoc($result)) {
            $events[] = $event;
        }

        // Maksimal event per row dan row per slide
        $maxCardsPerRow = 4;
        $maxRowsPerSlide = 2;
        
        if(!empty($events)) {
        // Chunk data menjadi rows dengan maksimal 4 event
        $eventRows = array_chunk($events, $maxCardsPerRow);

        // Chunk rows menjadi slides dengan maksimal 2 rows
        $slides = array_chunk($eventRows, $maxRowsPerSlide);

        // Render slides
        foreach ($slides as $slideRows) {
            echo '<div class="swiper-slide">';
            echo '<div class="slide-content">';
            foreach ($slideRows as $rowEvents) {
                echo '<div class="event-row">';
                foreach ($rowEvents as $event) {
                  try{
                    $start_date_parts = getDateParts($event['start_date']);
                    $end_date_parts = getDateParts($event['end_date']);
                    $SD_day = $start_date_parts['day_name'];
                    $SD_month = $start_date_parts['month_name'];
                    $SD_dayNumber = $start_date_parts['day_number'];
                    $ED_day = $end_date_parts['day_name'];
                    $ED_month = $end_date_parts['month_name'];
                    $ED_dayNumber = $end_date_parts['day_number'];
                    } catch (InvalidArgumentException $e) {   }
                    $Angkaharga = $event['harga'];
                    $harga = formatRupiah($Angkaharga); 
                    // Render card
                    echo '<article class="event-card">';
                    echo '<img class="event-card__image" src="./uploads/' . htmlspecialchars($event['foto_banner']) . '" alt="" />';
                    echo '<div class="event-card__content">';
                    echo '<div class="event-card__container">';
                    echo '<h2 class="event-card__title">' . htmlspecialchars($event['nama_event']) . '</h2>';
                    echo '<div class="event-card__details">';
                    echo '<div class="event-card__info-grid">';
                    echo '<div class="event-card__date-block">';
                    echo '<p class="event-card__date">' . htmlspecialchars($SD_month) . '<br />';
                    echo ($event['event_type'] === 'single') ? htmlspecialchars($SD_dayNumber) : "{$SD_dayNumber} - {$ED_dayNumber}";
                    echo '</span></p>';
                    echo '</div>';
                    echo '<div class="event-card__location-block">';
                    echo '<p class="event-card__location">' . ($event['location_type'] === 'online' ? 'ONLINE/ZOOM' : htmlspecialchars($event['address'])) . '</p>';
                    echo '<p class="event-card__time">' . htmlspecialchars("{$event['start_time_first']} - {$event['end_time_first']}") . '</p>';
                    echo '</div>';
                    echo '</div>';
                    echo '<div class="event-card__price-block">';
                    echo '<span class="event-card__price"><i class="fa-solid fa-ticket"></i> ' . ($event['jenis_tiket'] === 'free' ? 'FREE' : $harga) . '</span>';
                    echo '<p class="event-card_unavail">Tickets Available</p>';
                    echo '</div>';
                    echo '</div>';
                    echo '<nav class="event-button-nav" onclick="window.location.href=\'detail-event.php?event_id=' . $event['event_id'] . '\'">';
                    echo '<ul><li>More<span></span><span></span><span></span><span></span></li></ul>';
                    echo '</nav>';
                    echo '</div>';
                    echo '</article>';
                }
                echo '</div>'; // Close event-row
            }
            echo '</div>'; // Close slide-content
            echo '</div>'; // Close swiper-slide
          }
        } else {
          
        } ?>
    </div>
    </div>
    </div>
  </div>

  <!-- Free Events -->
  <div class="popular-container">
    <section class="popular-events-section">
      <h2 class="section-title">Free Events in USU</h2>
      <form action="events.php" method="POST" enctype="multipart/form-data">
        <div class="filters">
          <button type="submit" name="timesearch" value="all"
            class="filter-btn <?= (!isset($_POST['timesearch']) || $_POST['timesearch'] === 'all') ? 'active' : '' ?>">All</button>
          <button type="submit" name="timesearch" value="today"
            class="filter-btn <?= ($_POST['timesearch'] ?? '') === 'today' ? 'active' : '' ?>">Today</button>
          <button type="submit" name="timesearch" value="tomorrow"
            class="filter-btn <?= ($_POST['timesearch'] ?? '') === 'tomorrow' ? 'active' : '' ?>">Tomorrow</button>
          <button type="submit" name="timesearch" value="week"
            class="filter-btn <?= ($_POST['timesearch'] ?? '') === 'week' ? 'active' : '' ?>">This Week</button>
          <button type="submit" name="timesearch" value="month"
            class="filter-btn <?= ($_POST['timesearch'] ?? '') === 'month' ? 'active' : '' ?>">This Month</button>
        </div>
      </form>
    </section>
    
    
    <div class="swiper eventSwiper">
    <div class="swiper-wrapper">
        <?php
        // Contoh: Ambil semua event dari database
        $events = [];
        while ($event = pg_fetch_assoc($result_free)) {
            $events[] = $event;
        }

        // Maksimal event per row dan row per slide
        $maxCardsPerRow = 4;
        $maxRowsPerSlide = 2;
        
        if(!empty($events)) {
        // Chunk data menjadi rows dengan maksimal 4 event
        $eventRows = array_chunk($events, $maxCardsPerRow);

        // Chunk rows menjadi slides dengan maksimal 2 rows
        $slides = array_chunk($eventRows, $maxRowsPerSlide);

        // Render slides
        foreach ($slides as $slideRows) {
            echo '<div class="swiper-slide">';
            echo '<div class="slide-content">';
            foreach ($slideRows as $rowEvents) {
                echo '<div class="event-row">';
                foreach ($rowEvents as $event) {
                  try{
                    $start_date_parts = getDateParts($event['start_date']);
                    $end_date_parts = getDateParts($event['end_date']);
                    $SD_day = $start_date_parts['day_name'];
                    $SD_month = $start_date_parts['month_name'];
                    $SD_dayNumber = $start_date_parts['day_number'];
                    $ED_day = $end_date_parts['day_name'];
                    $ED_month = $end_date_parts['month_name'];
                    $ED_dayNumber = $end_date_parts['day_number'];
                    } catch (InvalidArgumentException $e) {   }
                    $Angkaharga = $event['harga'];
                    $harga = formatRupiah($Angkaharga); 
                    // Render card
                    echo '<article class="event-card">';
                    echo '<img class="event-card__image" src="./uploads/' . htmlspecialchars($event['foto_banner']) . '" alt="" />';
                    echo '<div class="event-card__content">';
                    echo '<div class="event-card__container">';
                    echo '<h2 class="event-card__title">' . htmlspecialchars($event['nama_event']) . '</h2>';
                    echo '<div class="event-card__details">';
                    echo '<div class="event-card__info-grid">';
                    echo '<div class="event-card__date-block">';
                    echo '<p class="event-card__date">' . htmlspecialchars($SD_month) . '<br />';
                    echo ($event['event_type'] === 'single') ? htmlspecialchars($SD_dayNumber) : "{$SD_dayNumber} - {$ED_dayNumber}";
                    echo '</span></p>';
                    echo '</div>';
                    echo '<div class="event-card__location-block">';
                    echo '<p class="event-card__location">' . ($event['location_type'] === 'online' ? 'ONLINE/ZOOM' : htmlspecialchars($event['address'])) . '</p>';
                    echo '<p class="event-card__time">' . htmlspecialchars("{$event['start_time_first']} - {$event['end_time_first']}") . '</p>';
                    echo '</div>';
                    echo '</div>';
                    echo '<div class="event-card__price-block">';
                    echo '<span class="event-card__price"><i class="fa-solid fa-ticket"></i> ' . ($event['jenis_tiket'] === 'free' ? 'FREE' : $harga) . '</span>';
                    echo '<p class="event-card_unavail">Tickets Available</p>';
                    echo '</div>';
                    echo '</div>';
                    echo '<nav class="event-button-nav" onclick="window.location.href=\'detail-event.php?event_id=' . $event['event_id'] . '\'">';
                    echo '<ul><li>More<span></span><span></span><span></span><span></span></li></ul>';
                    echo '</nav>';
                    echo '</div>';
                    echo '</article>';
                }
                echo '</div>'; // Close event-row
            }
            echo '</div>'; // Close slide-content
            echo '</div>'; // Close swiper-slide
          }
        } else {
          
        } ?>
    </div>
    </div>
    </div>
  </div>

  <!-- Online Events -->
  <div class="popular-container">
    <section class="popular-events-section">
      <h2 class="section-title">Online Events in USU</h2>
      <form action="events.php" method="POST" enctype="multipart/form-data">
        <div class="filters">
          <button type="submit" name="timesearch" value="all"
            class="filter-btn <?= (!isset($_POST['timesearch']) || $_POST['timesearch'] === 'all') ? 'active' : '' ?>">All</button>
          <button type="submit" name="timesearch" value="today"
            class="filter-btn <?= ($_POST['timesearch'] ?? '') === 'today' ? 'active' : '' ?>">Today</button>
          <button type="submit" name="timesearch" value="tomorrow"
            class="filter-btn <?= ($_POST['timesearch'] ?? '') === 'tomorrow' ? 'active' : '' ?>">Tomorrow</button>
          <button type="submit" name="timesearch" value="week"
            class="filter-btn <?= ($_POST['timesearch'] ?? '') === 'week' ? 'active' : '' ?>">This Week</button>
          <button type="submit" name="timesearch" value="month"
            class="filter-btn <?= ($_POST['timesearch'] ?? '') === 'month' ? 'active' : '' ?>">This Month</button>
        </div>
      </form>
    </section>

    <div class="event-grid">
    <div class="swiper eventSwiper">
    <div class="swiper-wrapper">
        <?php
        // Contoh: Ambil semua event dari database
        $events = [];
        while ($event = pg_fetch_assoc($result_online)) {
            $events[] = $event;
        }

        // Maksimal event per row dan row per slide
        $maxCardsPerRow = 4;
        $maxRowsPerSlide = 2;
        
        if(!empty($events)) {
        // Chunk data menjadi rows dengan maksimal 4 event
        $eventRows = array_chunk($events, $maxCardsPerRow);

        // Chunk rows menjadi slides dengan maksimal 2 rows
        $slides = array_chunk($eventRows, $maxRowsPerSlide);

        // Render slides
        foreach ($slides as $slideRows) {
            echo '<div class="swiper-slide">';
            echo '<div class="slide-content">';
            foreach ($slideRows as $rowEvents) {
                echo '<div class="event-row">';
                foreach ($rowEvents as $event) {
                  try{
                    $start_date_parts = getDateParts($event['start_date']);
                    $end_date_parts = getDateParts($event['end_date']);
                    $SD_day = $start_date_parts['day_name'];
                    $SD_month = $start_date_parts['month_name'];
                    $SD_dayNumber = $start_date_parts['day_number'];
                    $ED_day = $end_date_parts['day_name'];
                    $ED_month = $end_date_parts['month_name'];
                    $ED_dayNumber = $end_date_parts['day_number'];
                    } catch (InvalidArgumentException $e) {   }
                    $Angkaharga = $event['harga'];
                    $harga = formatRupiah($Angkaharga); 
                    // Render card
                    echo '<article class="event-card">';
                    echo '<img class="event-card__image" src="./uploads/' . htmlspecialchars($event['foto_banner']) . '" alt="" />';
                    echo '<div class="event-card__content">';
                    echo '<div class="event-card__container">';
                    echo '<h2 class="event-card__title">' . htmlspecialchars($event['nama_event']) . '</h2>';
                    echo '<div class="event-card__details">';
                    echo '<div class="event-card__info-grid">';
                    echo '<div class="event-card__date-block">';
                    echo '<p class="event-card__date">' . htmlspecialchars($SD_month) . '<br />';
                    echo ($event['event_type'] === 'single') ? htmlspecialchars($SD_dayNumber) : "{$SD_dayNumber} - {$ED_dayNumber}";
                    echo '</span></p>';
                    echo '</div>';
                    echo '<div class="event-card__location-block">';
                    echo '<p class="event-card__location">' . ($event['location_type'] === 'online' ? 'ONLINE/ZOOM' : htmlspecialchars($event['address'])) . '</p>';
                    echo '<p class="event-card__time">' . htmlspecialchars("{$event['start_time_first']} - {$event['end_time_first']}") . '</p>';
                    echo '</div>';
                    echo '</div>';
                    echo '<div class="event-card__price-block">';
                    echo '<span class="event-card__price"><i class="fa-solid fa-ticket"></i> ' . ($event['jenis_tiket'] === 'free' ? 'FREE' : $harga) . '</span>';
                    echo '<p class="event-card_unavail">Tickets Available</p>';
                    echo '</div>';
                    echo '</div>';
                    echo '<nav class="event-button-nav" onclick="window.location.href=\'detail-event.php?event_id=' . $event['event_id'] . '\'">';
                    echo '<ul><li>More<span></span><span></span><span></span><span></span></li></ul>';
                    echo '</nav>';
                    echo '</div>';
                    echo '</article>';
                }
                echo '</div>'; // Close event-row
            }
            echo '</div>'; // Close slide-content
            echo '</div>'; // Close swiper-slide
          }
        } else {
          
        } ?>
    </div>
    </div>
    </div>
  </div>

  <!-- Footer -->
  <?php include 'footer.php'; ?>

  <!-- Script Navbar -->
  <script>
    window.addEventListener("scroll", function () {
      var navbar = document.querySelector(".navbar");
      if (window.scrollY > 50) {
        navbar.classList.add("scrolled");
      } else {
        navbar.classList.remove("scrolled");
      }
    });
  </script>

  <!-- Script Preloader-->
  <script>
    document.addEventListener("DOMContentLoaded", function () {
      setTimeout(() => {
        const animationDuration = 700;
        const lastLetterDelay = 700;
        const totalDuration = animationDuration + lastLetterDelay;

        setTimeout(() => {
          const preloader = document.getElementById("preloader-wrapper");
          preloader.classList.add("hide-preloader");

          const mainContent = document.getElementById("main-content");
          mainContent.classList.add("show-content");

          setTimeout(() => {
            preloader.style.display = "none";
          }, 700);
        }, totalDuration);
      }, 700);
    });
  </script>

  <!-- Script Menu Mobile -->
  <script>
    const mobileMenuBtn = document.querySelector(".mobile-menu-btn");
    const nav = document.querySelector("nav");

    mobileMenuBtn.addEventListener("click", () => {
      nav.classList.toggle("active");
    });

    document.addEventListener("click", (e) => {
      if (!nav.contains(e.target) && !mobileMenuBtn.contains(e.target)) {
        nav.classList.remove("active");
      }
    });
  </script>

  <!-- Swiper JS -->
  <script>
    const swiper = new Swiper(".eventSwiper", {
      slidesPerView: 1, // Show one slide at a time
      spaceBetween: 30,
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      },
      // Optional: Add pagination
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
      // Optional: Enable loop
      loop: true,
      // Responsive breakpoints
      breakpoints: {
        // when window width is >= 768px
        768: {
          slidesPerView: 1,
        },
      },
    });
  </script>

  <script>
    document.addEventListener("DOMContentLoaded", function () {
      const swiper = new Swiper(".eventSwiper", {
        // Konfigurasi minimal
        slidesPerView: 1,
        spaceBetween: 10,
      });
    });
  </script>

  <!-- Script Bootstrap -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>

  <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
</body>

</html>