<?php
include 'db.php';
session_start();

if (!isset($_SESSION['id'])) {
  echo "<script>
          alert('Please Sign Up/Sign In First');
          window.location.href = 'register.php';
        </script>";
  exit;
}

$user_id = $_SESSION['id'];

// Ambil ID dari parameter GET
$event_id = $_GET['event_id'] ?? null;
$_SESSION['event_id'] = $_GET['event_id'];
if (!$event_id) {
  die("Event ID or Ticket ID is missing.");
}

// Ambil data event, termasuk kolom harga
$query = "SELECT * FROM tabel_event WHERE event_id = $1";
$result = pg_query_params($conn, $query, [$event_id]);

// Periksa hasil query
if ($result && pg_num_rows($result) > 0) {
  $event = pg_fetch_assoc($result);
  $harga = $event['harga']; // Ambil harga langsung dari hasil query
} else {
  // Jika event_id tidak valid
  $event = null; // Atau null jika seluruh data event tidak ditemukan
  $harga = 0;
}

if ($event && isset($event['start_date'], $event['end_date'])) {
  $start_date = $event['start_date'];
  $end_date = $event['end_date'];
  $gmaps_link = $event['gmaps_link'];

  function getDateParts($date)
  {
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
      throw new InvalidArgumentException("Format tidak valid: {$date}");
    }
    $timestamp = strtotime($date);
    return [
      'day_name' => date('l', $timestamp),
      'month_name' => strtoupper(date('M', $timestamp)),
      'day_number' => date('d', $timestamp)
    ];
  }

  try {
    $start_date_parts = getDateParts($start_date);
    $end_date_parts = getDateParts($end_date);

    $SD_day = $start_date_parts['day_name'];
    $SD_month = $start_date_parts['month_name'];
    $SD_dayNumber = $start_date_parts['day_number'];
    $ED_day = $end_date_parts['day_name'];
    $ED_month = $end_date_parts['month_name'];
    $ED_dayNumber = $end_date_parts['day_number'];
  } catch (InvalidArgumentException $e) {
    error_log("Error parsing dates: " . $e->getMessage());
    $SD_day = $ED_day = 'Unknown';
  }
} else {
  $SD_day = $ED_day = 'Unknown';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Detail Event - .Eventease</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&family=Abhaya+Libre:wght@400;500;600;700;800&family=Shrikhand&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" />
  <link rel="stylesheet" href="detail-event.css" />
  <script src="https://app.midtrans.com/snap/snap.js" data-client-key="SB-Mid-client-v4SsWBhCrOh_oa7J"></script>
</head>

<body>
  <?php
  include 'navbar.php';
  ?>

  <h1 class="header">
    Eventease: Your Gateway to the Hottest Events!
  </h1>
  <div class="content">
    <h2>
      <?= htmlspecialchars($event['nama_event']) ?>
    </h2>
    <div class="section">
      <img src="./uploads/<?= htmlspecialchars($event['foto_banner']) ?>" alt="Career Talk Event" class="event-image">
      <h3>Date and Time</h3>
      <?php if ($event['event_type'] == "single"): ?>
        <p><i class="fas fa-calendar-alt"></i> <?= htmlspecialchars("{$SD_day}, {$start_date}") ?></p>
        <p><i class="fas fa-clock"></i> <?= htmlspecialchars("{$event['start_time_first']} - {$event['end_time_first']} ") ?></p>
      <?php else: ?>
        <p><i class="fas fa-calendar-alt"></i> <?= htmlspecialchars("{$SD_day} - {$ED_day}, {$start_date} end {$end_date}") ?></p>
        <p><i class="fas fa-clock"></i> <?= htmlspecialchars("{$event['start_time_sec']} - {$event['end_time_sec']} end {$event['start_time_sec']} - {$event['end_time_sec']} ") ?></p>
      <?php endif; ?>
      <p class="add-to-calendar"><i class="fas fa-calendar-plus"></i>
        <a href="https://www.google.com/calendar/render?action=TEMPLATE&text=Roadshow+IDFest&dates=20241009T020000Z/20241010T100000Z&details=Roadshow+IDFest+di+Kota+Medan.&location=Aula+Fakultas+Ekonomi+dan+BISNIS+-+Universitas+Sumatera+Utara"> Add to Calendar</a>
      </p>
    </div>
    <div class="sectionMap">
      <h3>Location</h3>
      <?php if ($event['event_type'] == 'single'): ?>
        <p><i class="fa-solid fa-globe"></i> Online</p>
        <a href="<?= htmlspecialchars($event['online_link']) ?>"></a>
      <?php else : ?>
        <p><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($event['address']) ?></p>
        <?= $gmaps_link ?>
      <?php endif; ?>
    </div>
    <div class="sectionPrice">
      <h3>Ticket Information</h3>
      <p><i class="fas fa-ticket-alt"></i> <?= $event['jenis_tiket'] === 'free' ? 'FREE' : $harga ?></p>
    </div>
    <div>
      <form id="paymentForm" method="POST" action="transaction.php">
        <button type="button" class="btn buy-tickets-btn" data-bs-toggle="modal" data-bs-target="#payment1"><img src="images/tickets.png" alt="">Buy Ticket</button>

        <!-- Modal 1: Select Ticket -->
        <div class="modal fade" id="payment1" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h1 class="modal-title fs-5" id="staticBackdropLabel">SELECT TICKET</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <div class="d-flex justify-content-between pb-2 tiket_quantity">
                  <p><?= $event['jenis_tiket'] === 'free' ? 'FREE' : "PAID" ?></p>
                  <p style="padding: 0px 35px 0px 0px;">Quantity</p>
                </div>
                <div class="row jenis-tic">
                  <div class="col-warna col"></div>
                  <div class="nama-tic-col col">
                    <input type="hidden" name="product_price" value="<?= $harga ?>">
                    <h3><?= $event['nama_tiket'] ?></h3>
                    <p id="ticket-price" data-price="<?= $event['jenis_tiket'] === 'free' ? '0' : $event['harga'] ?>"><?= $event['jenis_tiket'] === 'free' ? 'Rp 0' : $harga ?></p>
                  </div>
                  <div class="col-md-4 ms-auto d-flex justify-content-between quantity">
                    <h3 class="bi bi-dash-circle" type="button" id="decrease-btn" style="cursor: pointer;"></h3>
                    <input type="number" value="1" min="1" id="quantity" name="quantity" readonly>
                    <h3 class="bi bi-plus-circle" type="button" id="increase-btn" style="cursor: pointer;"></h3>
                  </div>
                </div>
              </div>
              <div class="modal-footer">
                <div class="col d-flex totalSemen">
                  <h3>Qty: <span class="total-quantity">1</span></h3>
                  <h3>Total: <span class="total-price">Rp <?= number_format($event['jenis_tiket'] === 'free' ? 0 : $harga, 0, ',', '.') ?></span></h3>
                </div>
                <button type="button" class="btn btn-proses titleAdaBack" id="proceedButton">
                  <h1>Proceed<i class="bi bi-arrow-right"></i></h1>
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- Modal 2: Attendee Details -->
        <div class="modal fade" id="payment2" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <div class="col d-flex titleModalAdaBack">
                  <button id="backButton" type="button" class="btn btn-link" style="cursor: pointer;"><i class="bi bi-arrow-left"></i> </button>
                  <h1 class="modal-title fs-5" id="staticBackdropLabel">ATTENDEE DETAILS</h1>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <div class="d-flex justify-content-between pb-2 subtitleAttendee">
                  <p>
                    <?php
                    $nama_event = $event['nama_event'];
                    if (strlen($nama_event) >= 20) {
                      $nama_event = substr($nama_event, 0, 21) . '...';
                    }
                    echo htmlspecialchars($nama_event); ?>
                  </p>
                  <div class="d-flex justify-content-between">
                    <p><img src="images/calender.png" alt=""></p>
                    <p style="padding-left: 8px;">
                      <?= htmlspecialchars("{$SD_day}, {$start_date}") ?>
                    </p>
                  </div>
                </div>
                <p class="standard-ticket">Standard Ticket: Ticket #1</p>
                <div class="warna-summary"></div>
                <div class="row attendee-des">
                  <div class="form-group">
                    <label class="form-label" for="name">Full Name</label>
                    <input type="text" id="name" name="fullname" class="form-control" placeholder="Enter Attendee's full name" required>
                    <label class="form-label" for="email">Email</label>
                    <input type="email" id="email" name="email" class="form-control" placeholder="Enter Attendee's Email" required>
                    <label class="form-label" for="telepon" name="phone">Phone</label>
                    <div class="form-control">
                      <div class="d-flex telp-form">
                        <select id="country-code" name="country_code">
                          <option value="+1">USA (+1)</option>
                          <option value="+60">MYS (+60)</option>
                          <option value="+62">IDN (+62)</option>
                          <option value="+65">SGP (+65)</option>
                          <option value="+49">DEU (+49)</option>
                          <option value="+91">IND (+91)</option>
                          <option value="+82">KOR (+82)</option>
                        </select>
                        <input type="number" id="display-phone" placeholder="Enter Attendee's Phone Number" name="phone" required>
                      </div>
                    </div>
                  </div>
                </div>
                <p class="accept-terms">I accept all the <a href="terms.php">Terms of Service</a> and have read the <a href="terms.php">Privacy Policy</a></p>
              </div>
              <div class="modal-footer">
                <div class="col d-flex totalSemen">
                  <h3>Qty: <span class="total-quantity">1</span></h3>
                  <h3>Total: <span class="total-price">Rp <?= number_format($event['jenis_tiket'] === 'free' ? 0 : $harga, 0, ',', '.') ?></span></h3>
                </div>
                <button type="button" class="btn btn-proses titleAdaBack" id="toPayment3Button">
                  <h1>Proceed<i class="bi bi-arrow-right"></i></h1>
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- Modal 3: Order Summary -->
        <div class="modal fade" id="payment3" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
          aria-labelledby="staticBackdropLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <div class="col d-flex titleModalAdaBack">
                  <h3><i class="bi bi-arrow-left" type="button" data-bs-dismiss="modal" id="backTo2Button" style="cursor: pointer;"></i></h3>
                  <h1 class="modal-title fs-5" id="staticBackdropLabel">ORDER SUMMARY</h1>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <div class="warna-summary"></div>
                <div class="ticket">
                  <h1><?= $event['nama_tiket'] ?></h1>
                  <div>
                    <h3 class="attendee-name" id="display-name"></h3>
                    <div class="col d-flex justify-content-between harga-email">
                      <h3 class="attendee-email" id="display-email"></h3>
                      <h3 class="ticket-price fixtotal-price">Rp <?= number_format($event['jenis_tiket'] === 'free' ? 0 : $harga, 0, ',', '.') ?></h3>
                    </div>
                  </div>
                </div>
              </div>
              <div class="modal-footer">
                <div class="row footer-payment3">
                  <div class="col d-flex justify-content-between">
                    <h2>Subtotal:</h2>
                    <h3 class="total-price">Rp <?= number_format($event['jenis_tiket'] === 'free' ? 0 : $harga, 0, ',', '.') ?></h3>
                  </div>
                </div>
                <div class="row footer-payment3-tax">
                  <div class="col d-flex justify-content-between">
                    <h2>Tax:</h2>
                    <h3 class="tax-price">Rp <?= number_format(($event['jenis_tiket'] === 'free' ? 0 : $harga) * 0.1, 0, ',', '.') ?></h3>
                  </div>
                </div>
                <div class="row footer-payment3-total">
                  <div class="col d-flex justify-content-between">
                    <h2>Order Total:</h2>
                    <h3 class="fixtotal-price">Rp <?= number_format(($event['jenis_tiket'] === 'free' ? 0 : $harga) * 1.1, 0, ',', '.') ?></h3>
                  </div>
                </div>
                <?php if ($event['jenis_tiket'] === 'free'): ?>
                  <button type="submit" class="btn btn-proses titleAdaBack" data-bs-toggle="modal" data-bs-target="#payment4">
                    <h1>Pay Now</h1>
                  </button>
                <?php else: ?>
                  <button type="submit" class="btn btn-proses titleAdaBack" id="toPayment4Button">
                    <h1>Pay Now</h1>
                  </button>
                <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>

  <div class="modal fade" id="payment4" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <div class="col d-flex titleModalAdaBack">
            <h3><i class="bi bi-arrow-left" type="button" data-bs-dismiss="modal" id="backTo3Button"></i></h3>
            <h1 class="modal-title fs-5" id="staticBackdropLabel">PAYMENT</h1>
          </div>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>

        <div class="modal-body-pay">
          <div class="content-pay">
            <div class="circle-container">
              <div class="circle circle-4"></div>
              <div class="circle circle-3"></div>
              <div class="circle circle-2"></div>
              <div class="circle circle-1">
                <i class="fas fa-check"></i>
              </div>
            </div>
            <div class="message-pay">Payment Successful</div>
          </div>
          <div class="modal-footer">
            <button type="buttonNext" class="btn btn-proses titleAdaBack" onclick="window.location.href='home.php';">
              <h1>Continue</h1>
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="container">
    <section class="hosted-by">
      <div class="hostprofileContainer">
        <img alt="Host image" src="<?= './uploads/' . htmlspecialchars($event['hostprofile']) ?>" />
      </div>
      <div class="host-info">
        <h2><?= $event['hostname'] ?></h2>
        <div class="buttons">
          <button class="follow">
            <a style="text-decoration: none" class="follow" href="<?= 'https://wa.me/' . $event['host_telp'] ?>/">Contact</a>
          </button>
        </div>
      </div>
    </section>

    <section class="event-description">
      <p><?= nl2br(htmlspecialchars($event['description'], ENT_QUOTES, 'UTF-8')) ?></p>
    </section>
  </div>

  <?php
  include 'footer.php';
  ?>

  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="detail-event.js"></script>
</body>

</html>