<?php 
session_start();
include 'db.php';

require 'vendor/autoload.php';
require 'midtrans-config.php';

\Midtrans\Config::$serverKey = MIDTRANS_SERVER_KEY;
\Midtrans\Config::$isProduction = MIDTRANS_IS_PRODUCTION;
\Midtrans\Config::$isSanitized = true;
\Midtrans\Config::$is3ds = true;

$user_id = $_SESSION['id'];
$event_id = $_SESSION['event_id'];
$quantity = $_POST['quantity'];
$fullname = $_POST['fullname'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$product_price = $_POST['product_price'];
$tax = $product_price * 0.05;
$gross_amount = ($quantity * $product_price) + ($quantity * $tax);
$order_id = uniqid();

$query = "INSERT INTO transactions (id, event_id, order_id, fullname, email, phone, quantity, gross_amount, payment_status)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)";
$result = pg_query_params($conn, $query, [
    $user_id, $event_id, $order_id, $fullname, $email, $phone, $quantity, $gross_amount, 'pending'
]);

// Siapkan data request untuk API Midtrans
$params = array(
    'transaction_details' => array(
        'order_id' => $order_id,
        'gross_amount' => $gross_amount,
    ),
    'customer_details' => array(
        'first_name' => $fullname,
        'email' => $email,
        'phone' => $phone,
    ),
    // 'callback_url' => 'http://1234abcd.ngrok.io/payment-callback.php'
);

$snapToken = \Midtrans\Snap::getSnapToken($params);
echo $snapToken;
?>