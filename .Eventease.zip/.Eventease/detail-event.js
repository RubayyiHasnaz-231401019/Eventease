let isAvailable = false; // Status awal tiket

// Fungsi untuk mengubah status ketersediaan tiket
function toggleAvailability() {
  isAvailable = !isAvailable; // Toggle status tiket

  const availabilityDiv = document.getElementById('ticketAvailability');

  if (isAvailable) {
    availabilityDiv.textContent = "Tickets Available";
    availabilityDiv.classList.remove('unavailable');
    availabilityDiv.classList.add('available');
  } else {
    availabilityDiv.textContent = "Tickets Unavailable";
    availabilityDiv.classList.remove('available');
    availabilityDiv.classList.add('unavailable');
  }
}

// Modal Elements
const payment1ModalElement = document.getElementById('payment1');
const payment2ModalElement = document.getElementById('payment2');
const payment3ModalElement = document.getElementById('payment3');
const payment4ModalElement = document.getElementById('payment4');

// Modal Initialization
const payment1Modal = payment1ModalElement ? new bootstrap.Modal(payment1ModalElement) : null;
const payment2Modal = payment2ModalElement ? new bootstrap.Modal(payment2ModalElement) : null;
const payment3Modal = payment3ModalElement ? new bootstrap.Modal(payment3ModalElement) : null;
const payment4Modal = payment4ModalElement ? new bootstrap.Modal(payment4ModalElement) : null;

// Event Listener for Proceed Button
document.getElementById('proceedButton').addEventListener('click', function () {
  if (payment1Modal && payment2Modal) {
    payment1Modal.hide();
    payment2Modal.show();
  }
});

// Event Listener for Back Button
document.getElementById('backButton').addEventListener('click', function () {
  if (payment1Modal && payment2Modal) {
    payment2Modal.hide();
    payment1Modal.show();
  }
});

// Event Listener for toPayment3Button (Submit form and show payment 3 modal)
document.getElementById('toPayment3Button').addEventListener('click', function (event) {
  event.preventDefault(); // Prevent form from submitting

  const nameInput = document.getElementById('name');
  const emailInput = document.getElementById('email');
  const phoneInput = document.querySelector('input[type="number"]');

  // Validate form inputs
  if (!nameInput.value.trim() || !emailInput.value.trim() || !phoneInput.value.trim()) {
    alert('Please fill in all required fields.');
    return;
  }

  // Validate email format
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(emailInput.value)) {
    alert('Please enter a valid email address.');
    return;
  }

  // Capture user input for display
  const countryCode = document.getElementById('country-code').value;
  const phone = document.getElementById('display-phone').value;
  const fullPhone = `${countryCode} ${phone}`;

  document.getElementById('display-name').textContent = `${nameInput.value}`;
  document.getElementById('display-email').textContent = `${emailInput.value}`;
  document.getElementById('display-phone').textContent = `${fullPhone}`;

  // Hide payment 2 modal and show payment 3 modal
  if (payment2Modal && payment3Modal) {
    payment2Modal.hide();
    payment3Modal.show();
  }
});

const backTo2Button = document.getElementById('backTo2Button');
if (backTo2Button) {
  backTo2Button.addEventListener('click', function () {
    if (payment4Modal && payment3Modal) {
      payment4Modal.hide();
      payment3Modal.show();
    }
  });
} else {
  console.error("Button with ID 'backTo2Button' not found!");
}

// Event Listener for Back to Payment 2 Button
document.getElementById('backTo2Button').addEventListener('click', function () {
  if (payment3Modal && payment2Modal) {
    payment3Modal.hide();
    payment2Modal.show();
  }
});

// Event Listener for toPayment4Button (Submit transaction)
document.getElementById('toPayment4Button').addEventListener('click', async function () {
  const form = document.querySelector('form');
  const formData = new FormData(form);
  const data = new URLSearchParams(formData);
  
  try {
    const response = await fetch('transaction.php', {
      method: 'POST',
      body: data,
    });
    const token = await response.text();
    // console.log(token);
    window.snap.pay(token);
  } catch (err) {
    console.error(err.message);
  }

  // Hide payment 3 modal and show payment 4 modal
  if (payment3Modal) {
    payment3Modal.hide();
  }
});

document.addEventListener('DOMContentLoaded', function() {
  const backButton = document.getElementById('backButton');
  if (backButton) {
    backButton.addEventListener('click', function () {
      if (payment4Modal && payment3Modal) {
        payment4Modal.hide();
        payment3Modal.show();
      }
    });
  }
});

// Bagian Quantity Pop Up
const ticketPriceElement = document.getElementById('ticket-price');
const ticketPrice = parseFloat(ticketPriceElement.getAttribute('data-price')) || 0;

const quantityInput = document.getElementById('quantity');
const increaseBtn = document.getElementById('increase-btn');
const decreaseBtn = document.getElementById('decrease-btn');

// Fungsi untuk memperbarui display harga dan kuantitas
function updateDisplay() {
  let quantity = parseInt(quantityInput.value);

  if (isNaN(quantity) || quantity < 1) {
    quantity = 1; // Set default to 1 jika input invalid
    quantityInput.value = 1;
  }

  document.querySelectorAll('.total-quantity').forEach(el => {
    el.textContent = quantity;
  });

  const totalPrice = ticketPrice * quantity;
  document.querySelectorAll('.total-price').forEach(el => {
    el.textContent = `Rp${totalPrice.toLocaleString('id-ID')}.00`;
  });

  const taxPrice = totalPrice * 0.05;
  document.querySelectorAll('.tax-price').forEach(el => {
    el.textContent = `Rp${taxPrice.toLocaleString('id-ID')}.00`;
  });

  const finalTotal = totalPrice + taxPrice;
  document.querySelectorAll('.fixtotal-price').forEach(el => {
    el.textContent = `Rp${finalTotal.toLocaleString('id-ID')}.00`;
  });
}


// Event listener untuk menambah dan mengurangi kuantitas
increaseBtn.addEventListener('click', () => {
  console.log('Increase clicked');
  quantityInput.value = parseInt(quantityInput.value) + 1;
  updateDisplay();
});

decreaseBtn.addEventListener('click', () => {
  console.log('Decrease clicked');
  if (parseInt(quantityInput.value) > 1) {
    quantityInput.value = parseInt(quantityInput.value) - 1;
    updateDisplay();
  }
});

quantityInput.addEventListener('input', () => {
  if (parseInt(quantityInput.value) < 1) {
    quantityInput.value = 1;
  }
  updateDisplay();
});


updateDisplay();