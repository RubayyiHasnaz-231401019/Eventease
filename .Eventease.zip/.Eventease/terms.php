<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eventease - Terms of Service & Privacy Policy</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"></link>
    <!-- <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet"> -->
    <link rel="stylesheet" href="terms.css">
</head>
<body>

    <main class="container my-4">
        <section class="bg-white p-4 rounded shadow-sm mb-4 first">
            <div class="header-terms">
                <h2 class="h4 mb-3">Eventease Terms of Service</h2>
            </div>
            <p class="mb-3">Effective Date From: Sunday, 01 Dec 2024</p>
            <p class="mb-3">Hey there! Welcome to Eventease. By using our site to grab your tickets, check out events, or vibe with other features, you’re agreeing to follow our Terms of Service and Privacy Policy. If you're not down with this, you can bounce now.</p>
            <div class="accordion" id="termsAccordion">
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingOne">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            1. Your Account
                        </button>
                    </h2>
                    <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#termsAccordion">
                        <div class="accordion-body">
                            <p>To get the full Eventease experience (like buying tickets), you’ll need an account. Keep your login details safe, ‘cause you’re responsible for what happens under your profile. By signing up, you're telling us your info is real, accurate, and up-to-date. No fake stuff, please.</p>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingTwo">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                            2. Event Listings & Ticket Purchases
                        </button>
                    </h2>
                    <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#termsAccordion">
                        <div class="accordion-body">
                            <p>We’re here to connect you with cool events, but we don’t host them ourselves. The event organizers make the listings, and we just help you score tickets. Make sure you’ve got your payment ready ‘cause once you hit "buy," the deal’s done. If tickets aren’t available, we’ll let you know!</p>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingThree">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            3. Payments & Refunds
                        </button>
                    </h2>
                    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#termsAccordion">
                        <div class="accordion-body">
                            <p>Ticket prices are listed on our site. You’ll pay via our secure payment options. No takebacks, so double-check before you confirm your order. Tickets are non-refundable unless the event organizer has a different policy. For refunds or exchanges, hit up the event organizer.</p>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingFour">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                            4. Event Cancellations/Changes
                        </button>
                    </h2>
                    <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#termsAccordion">
                        <div class="accordion-body">
                            <p>Eventease isn’t in charge of event changes, cancellations, or rescheduling. If an event is canceled or changed, the event organizers will reach out to you directly. Refunds and exchanges are up to them, so check their policies.</p>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingFive">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                            5. Play Nice
                        </button>
                    </h2>
                    <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#termsAccordion">
                        <div class="accordion-body">
                            <p>Use Eventease respectfully. No trolling, spamming, or posting anything sketchy. We want everyone to enjoy browsing events without drama. If you break the rules, we’ll have to step in.</p>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingSix">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                            6. Your Privacy
                        </button>
                    </h2>
                    <div id="collapseSix" class="accordion-collapse collapse" aria-labelledby="headingSix" data-bs-parent="#termsAccordion">
                        <div class="accordion-body">
                            <p>We take your privacy seriously. By using Eventease, you're agreeing to our Privacy Policy, which explains how we collect, use, and protect your info. Go check it out for the full scoop.</p>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingSeven">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                            7. Not Our Fault
                        </button>
                    </h2>
                    <div id="collapseSeven" class="accordion-collapse collapse" aria-labelledby="headingSeven" data-bs-parent="#termsAccordion">
                        <div class="accordion-body">
                            <p>We’re not liable for any issues you might run into while using our site, like if you have trouble buying tickets, or if the event you wanted to attend gets canceled. We can’t control everything, and we’re not responsible for what happens at events or how event organizers manage things.</p>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingEight">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
                            8. Updates to These Terms
                        </button>
                    </h2>
                    <div id="collapseEight" class="accordion-collapse collapse" aria-labelledby="headingEight" data-bs-parent="#termsAccordion">
                        <div class="accordion-body">
                            <p>We might tweak these Terms every now and then. When we do, we’ll update this page with the new version and the date it took effect. By continuing to use Eventease, you’re cool with whatever changes we make.</p>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingNine">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
                            9. Got Questions?
                        </button>
                    </h2>
                    <div id="collapseNine" class="accordion-collapse collapse" aria-labelledby="headingNine" data-bs-parent="#termsAccordion">
                        <div class="accordion-body">
                            <p>If you’ve got any questions or need to talk, hit us up at:</p>
                            <p>Eventease Support</p>
                            <p>Email: noreply.eventease@gmail.com</p>
                            <p>Web : eventease.id</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="bg-white p-4 rounded shadow-sm">
            <div class="header-terms">
                <h2 class="h4 mb-3">Eventease Privacy Policy</h2>
            </div>
            <p class="mb-3">Effective Date From: Sunday, 01 Dec 2024</p>
            <p class="mb-3">Your privacy is important to us. This Privacy Policy explains how we collect, use, and protect your information when you use Eventease.</p>
            <div class="accordion" id="privacyAccordion">
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingTen">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTen" aria-expanded="true" aria-controls="collapseTen">
                            1. Information We Collect
                        </button>
                    </h2>
                    <div id="collapseTen" class="accordion-collapse collapse show" aria-labelledby="headingTen" data-bs-parent="#privacyAccordion">
                        <div class="accordion-body">
                            <p>We collect information you provide when you create an account, buy tickets, or interact with our site. This includes your name, email, payment details, and any other info you share with us.</p>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingEleven">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseEleven" aria-expanded="false" aria-controls="collapseEleven">
                            2. How We Use Your Information
                        </button>
                    </h2>
                    <div id="collapseEleven" class="accordion-collapse collapse" aria-labelledby="headingEleven" data-bs-parent="#privacyAccordion">
                        <div class="accordion-body">
                            <p>We use your information to provide and improve our services, process transactions, and communicate with you. We may also use your info for marketing purposes, but you can opt out anytime.</p>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingTwelve">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwelve" aria-expanded="false" aria-controls="collapseTwelve">
                            3. Sharing Your Information
                        </button>
                    </h2>
                    <div id="collapseTwelve" class="accordion-collapse collapse" aria-labelledby="headingTwelve" data-bs-parent="#privacyAccordion">
                        <div class="accordion-body">
                            <p>We don’t share your personal information with third parties except as needed to provide our services (like payment processors) or as required by law.</p>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingThirteen">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThirteen" aria-expanded="false" aria-controls="collapseThirteen">
                            4. Security
                        </button>
                    </h2>
                    <div id="collapseThirteen" class="accordion-collapse collapse" aria-labelledby="headingThirteen" data-bs-parent="#privacyAccordion">
                        <div class="accordion-body">
                            <p>We take security seriously and use measures to protect your information. However, no system is completely secure, so we can’t guarantee absolute security.</p>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingFourteen">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFourteen" aria-expanded="false" aria-controls="collapseFourteen">
                            5. Your Choices
                        </button>
                    </h2>
                    <div id="collapseFourteen" class="accordion-collapse collapse" aria-labelledby="headingFourteen" data-bs-parent="#privacyAccordion">
                        <div class="accordion-body">
                            <p>You can update your account information or delete your account at any time. You can also opt out of marketing communications by following the instructions in the emails we send you.</p>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingFifteen">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFifteen" aria-expanded="false" aria-controls="collapseFifteen">
                            6. Changes to This Policy
                        </button>
                    </h2>
                    <div id="collapseFifteen" class="accordion-collapse collapse" aria-labelledby="headingFifteen" data-bs-parent="#privacyAccordion">
                        <div class="accordion-body">
                            <p>We may update this Privacy Policy from time to time. When we do, we’ll post the new version on this page with the effective date. By continuing to use Eventease, you agree to the updated policy.</p>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingSixteen">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSixteen" aria-expanded="false" aria-controls="collapseSixteen">
                            7. Contact Us
                        </button>
                    </h2>
                    <div id="collapseSixteen" class="accordion-collapse collapse" aria-labelledby="headingSixteen" data-bs-parent="#privacyAccordion">
                        <div class="accordion-body">
                            <p>If you have any questions about this Privacy Policy or our practices, please contact us at:</p>
                            <p>Eventease Support</p>
                            <p>Email: noreply.eventease@gmail.com</p>
                            <p>Web : eventease.id</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <footer class="bg-primary text-white p-4 mt-4">
        <div class="container text-center">
            <p>&copy; 2024 Eventease. All rights reserved.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>