<?php
include 'db.php';
include 'notifikasi.php';
session_start();
$isLogin = isset($_SESSION['id']);
function formatRupiah($angka) {
  return "Rp " . number_format($angka, 0, ",", ".");
}
$eventsearch = $_POST['eventsearch'] ?? '';
$place_filter = $_POST['place_filter'] ?? '';
$timesearch = $_POST['timesearch'] ?? 'all';
$category = $_POST['category'] ?? 'all';
$conditions = [];
$params = [];
$paramIndex = 1;

if ($category !== 'all') {
  $conditions[] = "event_category = $" . $paramIndex++;
  $params[] = $category;
}
if (!empty($eventsearch)) {
    $conditions[] = "nama_event ILIKE $" . $paramIndex++;
    $params[] = "%$eventsearch%";
}
if (!empty($place_filter)) {
    $conditions[] = "address ILIKE $" . $paramIndex++;
    $params[] = "%$place_filter%";
}
if ($timesearch === 'today') {
  $conditions[] = "DATE(start_date) = CURRENT_DATE";
} elseif ($timesearch === 'tomorrow') {
  $conditions[] = "DATE(start_date) = CURRENT_DATE + INTERVAL '1 day'";
} elseif ($timesearch === 'week') {
  $conditions[] = "DATE(start_date) >= CURRENT_DATE AND DATE(start_date) <= CURRENT_DATE + INTERVAL '7 days'";
} elseif ($timesearch === 'month') {
  $conditions[] = "DATE(start_date) >= CURRENT_DATE AND DATE(start_date) <= CURRENT_DATE + INTERVAL '1 month'";
} elseif ($timesearch === 'offline') {
    $conditions[] = "location_type = 'offline'";
} elseif ($timesearch === 'free') {
    $conditions[] = "jenis_tiket = 'free'";
}
$whereClause = "";
if (!empty($conditions)) {
    $whereClause = " AND " . implode(' AND ', $conditions);
}
$query = "SELECT * FROM tabel_event WHERE status='published'" . $whereClause;
$result = pg_query_params($conn, $query, $params);

$query_free = "SELECT * FROM tabel_event WHERE status='published' AND jenis_tiket='free'" . $whereClause;
$result_free = pg_query_params($conn, $query_free, $params);

$query_online = "SELECT * FROM tabel_event WHERE status='published' AND location_type='online'" . $whereClause;
$result_online = pg_query_params($conn, $query_online, $params);


function getDateParts($date) {
  if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
      throw new InvalidArgumentException("Format tidak valid: {$date}");
  }
  $timestamp = strtotime($date);
  return [
      'day_name' => date('l', $timestamp),
      'month_name' => strtoupper(date('M', $timestamp)),
      'day_number' => date('d', $timestamp)
  ];
} 
?>