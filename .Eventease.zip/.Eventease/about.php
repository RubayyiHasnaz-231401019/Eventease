<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Eventease - Your Gateway to USU Events</title>
  <link rel="stylesheet" href="about.css" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&family=Abhaya+Libre:wght@400;500;600;700;800&family=Shrikhand&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
</head>

<body>
  <?php include 'navbar.php' ?>

  <!-- Hero Section Container -->
  <div class="hero-gallery-container">
    <!-- Hero Content -->
    <div class="hero-section">
      <div class="hero-content">
        <h1>.Eventease: Your Gateway to the Hottest Events in USU!</h1>
        <h2>About Us</h2>
        <p>
          Eventease is your go-to platform for discovering and experiencing
          the most epic events, competitions, and seminars at Universitas
          Sumatera Utara (USU). We make it easy for you to find, book, and
          live the best moments with just one click! From electrifying
          performances to inspiring talks, we're here to bring you closer to
          the events that elevate your day.
        </p>
        <p>
          Whether you're a thrill-seeker, a competitor, or just looking for an
          unforgettable experience, Eventease has something for everyone. So
          why wait? Snag your tickets now, join the vibe, and create memories
          that last a lifetime! 🎟👇
        </p>
      </div>
    </div>
  </div>

  <!-- Team Section -->
  <div class="container">
    <h2 class="team-title">Meet Our Team</h2>
    <div class="slide-wrapper">
      <div class="card-list swiper-wrapper">
        <div class="card-item swiper-slide">
          <img src="images/chika.jpeg" alt="Team Image" class="team-image" />
          <h2 class="team-name">Cantyka Laily Sabila</h2>
          <p class="team-profession">Frontend</p>
          <button class="message-button" onclick="window.location.href='https://mail.google.com/mail/?view=cm&fs=1&to=cantyka.chika175@gmail.com&su=Hello&body=Hi there!'">Message</button>
        </div>

        <div class="card-item swiper-slide">
          <img src="images/rubayyi.jpeg" alt="Team Image" class="team-image" />
          <h2 class="team-name">Rubayyi Hasnaz</h2>
          <p class="team-profession">Frontend</p>
          <button class="message-button" onclick="window.location.href='https://mail.google.com/mail/?view=cm&fs=1&to=hasnazrubayyi@gmail.com&su=Hello&body=Hi there!'">Message</button>
        </div>

        <div class="card-item swiper-slide">
          <img src="images/izzati.jpeg" alt="Team Image" class="team-image" />
          <h2 class="team-name">Nur Aliza Izzati</h2>
          <p class="team-profession">Backend</p>
          <button class="message-button" onclick="window.location.href='https://mail.google.com/mail/?view=cm&fs=1&to=hasnazrubayyi@gmail.com&su=Hello&body=Hi there!'">Message</button>
        </div>

        <div class="card-item swiper-slide">
          <img src="images/nyssa.jpeg" alt="Team Image" class="team-image" />
          <h2 class="team-name">Nyssa Obelia</h2>
          <p class="team-profession">Frontend</p>
          <button class="message-button" onclick="window.location.href='https://mail.google.com/mail/?view=cm&fs=1&to=nyssaakun@gmail.com&su=Hello&body=Hi there!'">Message</button>
        </div>

        <div class="card-item swiper-slide">
          <img src="images/nisa.jpg" alt="Team Image" class="team-image" />
          <h2 class="team-name">Khairunnisa Siregar</h2>
          <p class="team-profession">Backend</p>
          <button class="message-button" onclick="window.location.href='https://mail.google.com/mail/?view=cm&fs=1&to=khairnnisasrg08@gmail.com&su=Hello&body=Hi there!'">Message</button>
        </div>
      </div>

      <div class="swiper-pagination"></div>
      <div class="swiper-button-prev"></div>
      <div class="swiper-button-next"></div>
    </div>
  </div>

  <?php include 'footer.php' ?>

  <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
  <script>
    document.addEventListener("DOMContentLoaded", function() {
      setTimeout(() => {
        const animationDuration = 700;
        const lastLetterDelay = 700;
        const totalDuration = animationDuration + lastLetterDelay;

        setTimeout(() => {
          const preloader = document.getElementById("preloader-wrapper");
          preloader.classList.add("hide-preloader");

          const mainContent = document.getElementById("main-content");
          mainContent.classList.add("show-content");

          setTimeout(() => {
            preloader.style.display = "none";
          }, 700);
        }, totalDuration);
      }, 700);
    });
  </script>

  <script>
    const mobileMenuBtn = document.querySelector(".mobile-menu-btn");
    const nav = document.querySelector("nav");

    mobileMenuBtn.addEventListener("click", () => {
      nav.classList.toggle("active");
    });

    document.addEventListener("click", (e) => {
      if (!nav.contains(e.target) && !mobileMenuBtn.contains(e.target)) {
        nav.classList.remove("active");
      }
    });
  </script>

  <script>
    const swiper = new Swiper(".slide-wrapper", {
      loop: true,
      grabCursor: true,
      spaceBetween: 30,
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
        dynamicBullets: true,
      },
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      },
      breakpoints: {
        0: {
          slidesPerView: 1,
        },
        768: {
          slidesPerView: 2,
        },
        1024: {
          slidesPerView: 3,
        },
      },
    });
  </script>

  <script>
    document.addEventListener("DOMContentLoaded", () => {
      const nav = document.querySelector("nav");

      window.addEventListener("scroll", () => {
        if (window.scrollY > 50) {
          nav.classList.add("bg-dark");
        } else {
          nav.classList.remove("bg-dark");
        }
      });
    });
  </script>
</body>
</html>