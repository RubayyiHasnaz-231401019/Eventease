<?php
include 'db.php';
session_start();

$user_id = $_SESSION['id'];
$event_id = isset($_GET['event_id']) ? $_GET['event_id'] : null;
$sql = "SELECT * FROM tabel_event WHERE status = $1 AND id = $2";
$result = pg_query_params($conn, $sql, ['draft', $user_id]);

if (!$result) {
  die("Gagal mengambil data: " . pg_last_error($conn));
}
function getDateParts($date)
{
  if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
    throw new InvalidArgumentException("Format tidak valid: {$date}");
  }
  $timestamp = strtotime($date);
  return [
    'day_name' => date('l', $timestamp),
    'month_name' => strtoupper(date('M', $timestamp)),
    'day_number' => date('d', $timestamp)
  ];
}
if (isset($_POST['hapus'])) {
  $event_id = $_POST['event_id'] ?? null;
  if (!$event_id || !is_numeric($event_id)) {
    die("Event ID tidak valid.");
  }
  $sql = "DELETE FROM tabel_event WHERE event_id = $1";
  $result = pg_query_params($conn, $sql, [$event_id]);
  if ($result) {
    // header("Location: draft.php");
    exit;
  } else {
    die("Gagal menghapus event: " . pg_last_error($conn));
  }
}
function formatRupiah($angka)
{
  return "Rp " . number_format($angka, 0, ",", ".");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Draft - .Eventease</title>
  <link rel="stylesheet" href="profile.css" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&family=Abhaya+Libre:wght@400;500;600;700;800&family=Shrikhand&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" />
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.3.2/css/bootstrap.min.css" />
</head>

<body>
  <?php
  include 'navbar.php';
  ?>

  <div class="container">
    <div class="content">
      <div class="header">
        <h2>Draft Event</h2>
      </div>
      <?php if (pg_num_rows($result)): ?>
        <?php while ($event = pg_fetch_assoc($result)):
          try {
            $start_date_parts = getDateParts($event['start_date']);
            $end_date_parts = getDateParts($event['end_date']);
            $SD_day = $start_date_parts['day_name'];
            $SD_month = $start_date_parts['month_name'];
            $SD_dayNumber = $start_date_parts['day_number'];
            $ED_day = $end_date_parts['day_name'];
            $ED_month = $end_date_parts['month_name'];
            $ED_dayNumber = $end_date_parts['day_number'];
          } catch (InvalidArgumentException $e) {
            error_log("Error parsing date: " . $e->getMessage());
            $SD_dayNumber = '??';
            $SD_month = '??';
          }
          $Angkaharga = $event['harga'];
          $harga = formatRupiah($Angkaharga);
        ?>
          <!-- <a style="text-decoration:none" href="review-event.php?event_id=<?= $event['event_id'] ?>"> -->
          <div class="order-item">
            <a type="hidden" style="text-decoration:none" href="review-event.php?event_id=<?= $event['event_id'] ?>">
              <div class="row d-flex baris">
                <div class="img-container">
                  <img alt="Event Picture" src="./uploads/<?= $event['foto_banner'] ?>" />
                </div>
                <div class="order-details">
                  <h3><?= $event['nama_event'] ?></h3>
                  <p> <?= $event['event_type'] === 'single' ? "{$SD_day}, {$event['start_date']}" : "{$SD_day} - {$ED_day}, {$event['start_date']}  en  {$event['end_date']}" ?> </p>
                </div>
                <div class="order-price">
                  <h3> <?= $event['jenis_tiket'] === 'free' ? "FREE TICKET" : "PAID TICKET" ?> </h3>
                  <p><?= $event['jenis_tiket'] === 'free' ? "Rp 0.00" : "Rp {$event['harga']}" ?> </p>
                </div>
              </div>
            </a>
            <form action="draft.php" method="POST" onsubmit="return confirm('Are you sure want to delete this event?');">
              <input type="hidden" name="event_id" value="<?= $event['event_id'] ?>">
              <button type="submit" name="hapus" class="opsi">
                <h1><i class="fa-solid fa-trash"></i></h1>
              </button>
            </form>

          </div>
        <?php endwhile; ?>
      <?php else : ?>
        <section class="tessaja" style="text-align: center; height: 300px; padding-top: 30px">
          <h1>No events found.</h1>
        </section>
      <?php endif; ?>
    </div>
  </div>
  </div>

  <?php
  include 'footer.php';
  ?>

  <script>
    const mobileMenuBtn = document.querySelector(".mobile-menu-btn");
    const nav = document.querySelector("nav");

    mobileMenuBtn.addEventListener("click", () => {
      nav.classList.toggle("active");
    });

    document.addEventListener("click", (e) => {
      if (!nav.contains(e.target) && !mobileMenuBtn.contains(e.target)) {
        nav.classList.remove("active");
      }
    });
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>