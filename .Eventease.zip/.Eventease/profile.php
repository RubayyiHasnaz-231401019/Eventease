<?php
include 'db.php';
session_start();

$user_id = $_SESSION['id'];

$query = "SELECT * FROM users WHERE id = $1";
$result = pg_query_params($conn, $query, array($user_id));
$user = pg_fetch_assoc($result);

$success = '';
$error = '';

$has_password = !empty($user['password']);
 
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Bagian Update Account Information
    if (isset($_POST['update_account_info'])) {
        $first_name = $_POST['first_name'] ?? '';
        $last_name = $_POST['last_name'] ?? '';
        $phone_number = $_POST['phone_number'] ?? '';
        $address = $_POST['address'] ?? '';
        $city = $_POST['city'] ?? '';

        // Proses upload gambar (jika ada)
        if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
            $target_dir = "uploads/";
            $image_name = basename($_FILES['profile_picture']['name']);
            $target_file = $target_dir . $image_name;
            $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
            $file_size = $_FILES['profile_picture']['size'];

            $valid_extensions = array("jpg", "jpeg", "png");
            $max_file_size = 2 * 1024 * 1024; // Maksimal 2MB

            // Validasi ukuran file
            if ($file_size > $max_file_size) {
                $error = "The profile picture is too large. Maximum size allowed is 2MB.";
            }
            // Validasi format file
            elseif (!in_array($imageFileType, $valid_extensions)) {
                $error = "Invalid photo format. Please use JPG, JPEG, or PNG.";
            }
            // Jika validasi berhasil, lakukan upload
            else {
                if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $target_file)) {
                    $query = "UPDATE users SET first_name = $1, last_name = $2, phone_number = $3, address = $4, city = $5, profile_picture = $6 WHERE id = $7";
                    $result = pg_query_params($conn, $query, array($first_name, $last_name, $phone_number, $address, $city, $target_file, $user_id));
                    $success = $result ? "Account information updated successfully!" : pg_last_error($conn);
                } else {
                    $error = "Error uploading file. Please try again.";
                }
            }
        } else {
            $query = "UPDATE users SET first_name = $1, last_name = $2, phone_number = $3, address = $4, city = $5 WHERE id = $6";
            $result = pg_query_params($conn, $query, array($first_name, $last_name, $phone_number, $address, $city, $user_id));
            $success = $result ? "Account information updated successfully!" : pg_last_error($conn);
        }

        // Refresh data user
        $query = "SELECT * FROM users WHERE id = $1";
        $result = pg_query_params($conn, $query, array($user_id));
        $user = pg_fetch_assoc($result);
    }

    // Bagian Change Email
    if (isset($_POST['change_email'])) {
        $new_email = $_POST['new_email'] ?? '';
        $confirm_email = $_POST['confirm_email'] ?? '';
    
        // Validasi format email
        if (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
            $error = "Invalid email format.";
        }
    
        // Cek apakah email baru dan konfirmasi email cocok
        if (empty($error) && $new_email === $confirm_email) {
            // Cek apakah email sudah terdaftar
            $query = "SELECT id FROM users WHERE email = $1 AND id != $2"; 
            $result = pg_query_params($conn, $query, array($new_email, $user_id));
            
            if (pg_num_rows($result) > 0) {
                $error = "This email is already in use.";
            } else {
                // Jika email valid dan belum digunakan, update email
                $query = "UPDATE users SET email = $1 WHERE id = $2";
                $result = pg_query_params($conn, $query, array($new_email, $user_id));
                if ($result) {
                    $success = "Email updated successfully!";
                } else {
                    $error = "Error updating email: " . pg_last_error($conn);
                }
            }
        } else {
            $error = "Emails do not match!";
        }
    }
        
    // Bagian Change Password
    if (isset($_POST['change_password'])) {
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
    
        // Jika user sudah memiliki password (tanpa google_id)
        if ($has_password) {
            $current_password = $_POST['current_password'] ?? '';
    
            // Verifikasi password lama jika ada
            if (!password_verify($current_password, $user['password'])) {
                $error = "Current password is incorrect.";
            }
        }
    
        // Cek apakah password baru dan konfirmasi password cocok
        if (empty($error) && $new_password === $confirm_password) {
            if (strlen($new_password) < 8) {
                $error = "Password must be at least 8 characters long.";
            } else {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
    
                // Update password
                $query = "UPDATE users SET password = $1, has_password = TRUE WHERE id = $2";
                $result = pg_query_params($conn, $query, array($hashed_password, $user_id));
                if ($result) {
                    $success = "Password updated successfully!";
                } else {
                    $error = "Error updating password: " . pg_last_error($conn);
                }
            }
        } else {
            $error = empty($error) ? "Passwords do not match!" : $error;
        }
    }    
}
function getDateParts($date) {
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        throw new InvalidArgumentException("Format tidak valid: {$date}");
    }
    $timestamp = strtotime($date);
    return [
        'day_name' => date('l', $timestamp),
        'month_name' => strtoupper(date('M', $timestamp)),
        'day_number' => date('d', $timestamp)
    ];
  }

function formatRupiah($angka) {
    return "Rp " . number_format($angka, 0, ",", ".");
}
$kuery = "SELECT * FROM tabel_event WHERE status=$1 AND id=$2";
$hasil = pg_query_params($conn, $kuery, ['published', $user_id]);
if (isset($_POST['hapus'])) {
    $event_id = $_POST['event_id'] ?? null;
    if (!$event_id || !is_numeric($event_id)) {
        die("Event ID tidak valid.");
    }
    $sql = "DELETE FROM tabel_event WHERE event_id = $1";
    $result = pg_query_params($conn, $sql, [$event_id]);
    if ($result) {
        header("Location: profile.php#history");
        exit;
    } else {
        die("Gagal menghapus event: " . pg_last_error($conn));
    }
  }

$kuery = "SELECT * FROM transactions where user_id=$1";
$hasil_transaksi = pg_query_params($conn, $kuery, [$user_id]); 

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Profile Settings - .Eventease</title>
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"> -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&family=Abhaya+Libre:wght@400;500;600;700;800&family=Shrikhand&display=swap" rel="stylesheet"/>
    <link  rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"/>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
    <link rel="stylesheet" href="profile.css" />
</head>
<body>
    <?php include 'navbar.php' ?>
    <div class="container mt-5">
        <div class="sidebar">
            <h2>Profile</h2>
            <ul class="nav nav-tabs" id="profileTabs">
                <li class="nav-item">
                    <a class="nav-link active" href="#account-info" onclick="showTab('account-info')"><i class="fa fa-user"></i>  Account Information</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#change-email" onclick="showTab('change-email')"><i class="fa fa-envelope"></i>  Change Email</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#change-password" onclick="showTab('change-password')"><i class="fa fa-lock"></i>  Change Password</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#history" onclick="showTab('history')"><i class="fa fa-history"></i>  History</a>
                </li>
            </ul>
        </div>
        <div class="content">
            <div id="account-info" class="tab-content">
                <form method="post" enctype="multipart/form-data">
                    <div class="header">
                        <h2>Account Information</h2>
                    </div>
                    <div class="profile-container">
                        <div class="profile-pic" id="profilePic">
                            <img id="profileImage" src="<?php echo $user['profile_picture'] ?? 'images/userphoto.png'; ?>" alt="Profile Picture"/>
                        </div>
                        <label class="camera-icon" for="fileInput"><img alt="Camera icon" src="images/cameraicon.png"/></label>
                        <input id="fileInput" type="file" name="profile_picture" accept="image/*" onchange="loadFile(event)"/>
                    </div>
                    <div class="form-group">
                        <h3>Profile Information</h3>
                    </div>
                    <div class="form-group">
                        <label for="first-name">First Name:</label>
                        <input id="first-name" placeholder="Enter first name" type="text" name="first_name" value="<?php echo htmlspecialchars($user['first_name'] ?? ''); ?>"/>
                    </div>
                    <div class="form-group">
                        <label for="last-name">Last Name:</label>
                        <input id="last-name" placeholder="Enter last name" type="text" name="last_name" value="<?php echo htmlspecialchars($user['last_name'] ?? ''); ?>"/>
                    </div>
                    <div class="form-group">
                        <h3>Contact Details</h3>
                    </div>
                    <div class="form-group">
                        <label for="phone-number">Phone Number:</label>
                        <input id="phone-number" placeholder="Enter phone number" type="text" name="phone_number" value="<?php echo htmlspecialchars($user['phone_number'] ?? ''); ?>"/>
                    </div>
                    <div class="form-group">
                        <label for="address">Address:</label>
                        <input id="address" placeholder="Enter address" type="text" name="address" value="<?php echo htmlspecialchars($user['address'] ?? ''); ?>"/>
                    </div>
                    <div class="form-group">
                        <label for="city">City/Town:</label>
                        <input id="city" placeholder="Enter city/town" type="text" name="city" value="<?php echo htmlspecialchars($user['city'] ?? ''); ?>"/>
                    </div>
                    <div class="save-button" style="margin-bottom: 20px;">
                        <button onclick="saveChanges()"  name="update_account_info">Save Changes</button>
                    </div>
                </form>
            </div>
            <div id="change-email" class="tab-content" style="display:none;">
                <form method="post" enctype="multipart/form-data">
                    <div class="header">
                        <h2>Change Email</h2>
                    </div>
                    <div class="form-group" style="margin-top: 37px;">
                        <label class="block text-gray-700 mb-2">Current Email:</label>
                            <p><?php echo htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8'); ?></p>
                    </div>
                    <div class="form-group">
                        <label for="first-name">New Email:</label>
                        <input id="first-name" placeholder="Enter new email" type="text" name="new_email" required/>
                    </div>
                    <div class="form-group">
                        <label for="last-name">Confirm Email:</label>
                        <input id="last-name" placeholder="Enter email again" type="text" name="confirm_email" required/>
                    </div>
                    <div class="save-button">
                        <button name="change_email">Save Changes</button>
                    </div>
                </form>
            </div>
            <div id="change-password" class="tab-content" style="display:none;">
                <form method="post" enctype="multipart/form-data">
                    <div class="header">
                        <h2 style="margin-bottom: 20px;">Change Password</h2>
                    </div>
                    <?php if ($has_password): ?>
                        <div class="form-group">
                            <label for="first-name">Current Password:</label>
                            <input id="first-name" placeholder="Enter current password" type="text" name="current_password" required/>
                        </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <label for="first-name">New Password:</label>
                        <input id="first-name" placeholder="Enter new password" type="text" name="new_password" required/>
                    </div>
                    <div class="form-group">
                        <label for="last-name">Confirm Password:</label>
                        <input id="last-name" placeholder="Enter password again" type="text" name="confirm_password" required/>
                    </div>
                    <div class="save-button">
                        <button onclick="saveChanges()" name="change_password">Save Changes</button>
                    </div>
                </form>
            </div>
            <div id="history" class="tab-content active" style="display:none;">
                <div class="header">
                    <h2>Order & Sales History</h2>
                </div>
                <h3>My Sales : </h3>
                <?php if(pg_num_rows($hasil)) :?>
                <?php while ($event = pg_fetch_assoc($hasil)):
                    try {
                        $start_date_parts = getDateParts($event['start_date']);
                        $end_date_parts = getDateParts($event['end_date']);
                        $SD_day = $start_date_parts['day_name'];
                        $ED_day = $end_date_parts['day_name'];
                    }   catch (InvalidArgumentException $e) {
                        error_log("Error parsing date: " . $e->getMessage());
                        $SD_dayNumber = '??';
                        $SD_month = '??';
                    } 
                    $Angkaharga = $event['harga'];
                    $harga = formatRupiah($Angkaharga);?>
                <div class="order-item">
                    <a type="hidden" style="text-decoration:none" href="detail-event.php?event_id=<?= $event['event_id'] ?>">
                        <div class="img-container">
                            <img alt="Event Picture" src="./uploads/<?= $event['foto_banner']?>"/>
                        </div>
                        <div class="order-details">
                            <h3><?= $event['nama_event'] ?></h3>
                            <p> <?= $event['event_type'] ==='single' ? "{$SD_day}, {$event['start_date']}" : "{$SD_day} - {$ED_day}, {$event['start_date']}  en  {$event['end_date']}" ?> </p>
                        </div>
                        <div class="order-price">
                            <h3> <?= $event['jenis_tiket'] ==='free' ? "FREE TICKET" : "PAID TICKET"?> </h3>
                            <p><?= $event['jenis_tiket'] ==='free' ? "Rp 0.00" : "$harga"?> </p>
                        </div>
                    </a>
                    <form action="profile.php" method="POST" onsubmit="return confirm('Are you sure want to delete this event?');">
                        <input type="hidden" name="event_id" value="<?= $event['event_id'] ?>">
                        <button type="submit" name="hapus" class="opsi">
                            <h1><i class="fa-solid fa-trash"></i></h1> 
                        </button>
                    </form>
                </div
                <?php endwhile; 
                else : ?>
                    <h3 style="padding-block : 10px; color : grey; font-size: 20px">No Sales Event Founds.</h3>
                <?php endif; ?>

                <h3>My Order : </h3>
                    <?php if ($hasil_transaksi && pg_num_rows($hasil_transaksi) > 0): 
                    while ($transaksi = pg_fetch_assoc($hasil_transaksi)):
                        $event_id = $transaksi['event_id'];
                        $skl = "SELECT * FROM tabel_event WHERE event_id = $1";
                        $hasilnya = pg_query_params($conn, $skl, [$event_id]);
                        $total_amount = $transaksi['total_amount'];
                        $total_amount = formatRupiah($total_amount);
                        if ($hasilnya && ($event = pg_fetch_assoc($hasilnya))) {
                            $Angkaharga = $event['harga'];
                            $harga = formatRupiah($Angkaharga);
                            $tax_price = $event['harga'] * 0.5;
                            $tax_price = formatRupiah($tax_price);
                            try {
                                $start_date_parts = getDateParts($event['start_date']);
                                $end_date_parts = getDateParts($event['end_date']);
                                $SD_day = $start_date_parts['day_name'];
                                $ED_day = $end_date_parts['day_name'];
                            } catch (InvalidArgumentException $e) {  }
                        } 
                    ?>
                <div class="order-item" id="openModal">
                    <a type="hidden" style="text-decoration:none" href="#transactionModal<?= $transaksi['transaction_id'] ?>" >
                        <div class="img-container">
                            <img alt="Event Picture" src="./uploads/<?= htmlspecialchars($event['foto_banner']) ?>" />
                        </div>
                        <div class="order-details">
                            <h3><?= htmlspecialchars($event['nama_event']) ?></h3>
                            <p>
                                <?= $event['event_type'] === 'single' 
                                    ? "{$SD_day}, {$event['start_date']}" 
                                    : "{$SD_day} - {$ED_day}, {$event['start_date']} en {$event['end_date']}" ?>
                            </p>
                        </div>
                        <div class="order-price">
                            <h3><?= $event['jenis_tiket'] === 'free' ? "Rp 0.00" : $harga ?></h3>
                            <p><?= "Payment {$transaksi['payment_status']}" ?></p>
                        </div>
                    </a>
                    <form action="profile.php" method="POST" onsubmit="return confirm('Are you sure want to delete this event?');">
                        <input type="hidden" name="event_id" value="<?= htmlspecialchars($event['event_id']) ?>">
                        <button type="submit" name="hapus" class="opsi">
                            <h1><i class="fa-solid fa-trash"></i></h1> 
                        </button>
                    </form>
                </div>

                <div class="modal" id="transactionModal<?= $transaksi['transaction_id'] ?>">
                    <div class="modal-content" type="hidden">
                        <div class="modal-header">Transaction Details</div>
                        <div class="modal-body">
                            <p><strong>Order ID </strong></p>
                            <p><?= $transaksi['transaction_id'] ?></p>
                            <p><strong>Order Date</strong></p>
                            <p><?= $transaksi['created_at'] ?> </p>
                            <p><strong>Status Payment</strong></p>
                            <p><?= "{$transaksi['payment_status']} "?></p>
                            <p><strong>Quantity</strong></p>
                            <p><?= $transaksi['quantity'] ?></p>
                            <p><strong>Price per Ticket </strong></p>
                            <p> <?= $event['jenis_tiket'] === 'free' ? 'Rp 0' : $harga ?></p>
                            <p><strong>Tax</strong></p>
                            <p><?= $tax_price ?></p>
                            <p><strong>Total Amount</strong></p>
                            <p><?= $total_amount?></p>
                            <p class ="detailKecil">Ticket details has been sent to your email</p>
                        </div>
                        <div class="modal-footer">
                            <button class="close-button" id="closeModal">Close</button>
                        </div>
                    </div>
                </div>
                    <?php endwhile; 
                else: ?>
                    <h3 style="padding-block : 10px; color : grey; font-size: 20px">No Orders Event Found.</h3>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php include 'footer.php'?>  

    <?php if ($error): ?>
    <script type="text/javascript">
        alert("Error: <?php echo addslashes($error); ?>");
    </script>
    <?php endif; ?>

    <?php if ($success): ?>
    <script type="text/javascript">
        alert("Success: <?php echo addslashes($success); ?>");
    </script>
    <?php endif; ?>

    <script>
        function loadFile(event) {
        var image = document.getElementById('profileImage');
        image.src = URL.createObjectURL(event.target.files[0]);
        }
        function showTab(tabId) {
            console.log(`Switching to tab: ${tabId}`);
            const tabs = document.querySelectorAll('.tab-content');
            tabs.forEach(tab => tab.style.display = 'none');

            const links = document.querySelectorAll('.nav-link');
            links.forEach(link => link.classList.remove('active'));

            const targetTab = document.getElementById(tabId);
            if (targetTab) {
                targetTab.style.display = 'block';
                console.log(`Tab "${tabId}" is now visible.`);
            } else {
                console.error(`Tab "${tabId}" not found.`);
            }

            const activeLink = document.querySelector(`[href="#${tabId}"]`);
            if (activeLink) {
                activeLink.classList.add('active');
            }
        }

        document.addEventListener("DOMContentLoaded", function() {
            showTab('history'); // Default tab
        });

        //untuk modal
        
        document.addEventListener('DOMContentLoaded', function () {
        const modalLinks = document.querySelectorAll('a[href^="#transactionModal"]');
        modalLinks.forEach(link => {
            link.addEventListener('click', function (event) {
                event.preventDefault();
                const modalId = this.getAttribute('href').substring(1);
                const modal = document.getElementById(modalId);
                modal.style.display = 'block';
            });
        });

        const closeButtons = document.querySelectorAll('.close-button');
        closeButtons.forEach(button => {
            button.addEventListener('click', function () {
                const modal = this.closest('.modal');
                modal.style.display = 'none';
                });
            });
        });

        // const ticketPrice = parseFloat(ticketPriceElement.getAttribute('data-price')) || 0;
        // const ticketPriceElement = document.getElementById('ticket-price');
        // const ticketPrice = parseFloat(ticketPriceElement.getAttribute('data-price')) || 0;
        // document.querySelectorAll('.tax-price').forEach(el => {
        //     el.textContent = `Rp${(ticketPrice * 0.05).toLocaleString('id-ID')}.00`;
        // });
    </script>
</body>
</html>